package com.aram.aiquant
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme{var symbol by remember{mutableStateOf("BTCIRT")};Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){Text("ARAM AI QUANT",style=MaterialTheme.typography.headlineMedium);Text("100+ Agent • Master Engine • Red Team • Risk Engine");OutlinedTextField(value=symbol,onValueChange={symbol=it.uppercase()},label={Text("نماد")},modifier=Modifier.fillMaxWidth());Button(onClick={},modifier=Modifier.fillMaxWidth()){Text("تحلیل عمیق")};Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("BUY / SELL / WAIT / NO TRADE");Text("هسته آماده اتصال به داده بازار و تلگرام")}}}}}}}
