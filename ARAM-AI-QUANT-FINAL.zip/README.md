# ARAM AI QUANT
GitHub-ready Android shell for the ARAM AI QUANT architecture.

Target architecture: 100+ heterogeneous specialist agents, adaptive weighting, regime detection, Master Decision Engine, Red-Team validation, risk/thesis/invalidation monitoring, market-data adapters and Telegram alerts.

API keys and bot tokens must be supplied through secrets/configuration, never committed to the repository.
