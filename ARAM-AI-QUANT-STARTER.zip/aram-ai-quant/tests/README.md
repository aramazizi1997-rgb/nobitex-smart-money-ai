Add automated tests here as the market-data adapter and strategy are expanded.
