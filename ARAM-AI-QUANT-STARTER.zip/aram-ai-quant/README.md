# ARAM AI QUANT — Starter Project

A safe starter scaffold for a Persian-language market-monitoring Telegram bot. This is **not** a finished autonomous trading system and does not guarantee profitable signals. It does not place trades.

## Included
- Telegram bot command scaffold (`/start`, `/help`, `/status`)
- Basic market-data fetch scaffold for public Nobitex ticker endpoints
- Simple rule-based BUY / SELL / WAIT example with explicit risk disclaimer
- Environment-variable configuration

## Run locally
1. Install Python 3.11+.
2. Copy `.env.example` to `.env` and add your Telegram bot token.
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `python -m app.bot`

Never share your Telegram token publicly. Do not add exchange API keys unless you understand the risks. This starter does not execute trades.
