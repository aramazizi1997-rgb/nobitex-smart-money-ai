"""Public-market-data helper. No trading or private API access."""
from __future__ import annotations
import requests

BASE_URL = "https://api.nobitex.ir"


def get_ticker(src: str = "BTCIRT") -> dict:
    """Fetch a public ticker from Nobitex. API shape may change; handle errors safely."""
    response = requests.get(
        f"{BASE_URL}/market/stats",
        params={"src": src.lower()},
        timeout=10,
        headers={"User-Agent": "ARAM-AI-QUANT-starter/0.1"},
    )
    response.raise_for_status()
    data = response.json()
    stats = data.get("stats", {})
    ticker = stats.get(src.lower()) or stats.get(src.upper())
    if not isinstance(ticker, dict):
        raise ValueError(f"Ticker {src} not found in public API response")
    return ticker


def simple_signal(ticker: dict) -> str:
    """Illustrative rule only; not a reliable forecast or investment advice."""
    try:
        last = float(ticker.get("latest"))
        high = float(ticker.get("dayHigh"))
        low = float(ticker.get("dayLow"))
    except (TypeError, ValueError):
        return "WAIT — دادهٔ کافی یا معتبر نیست."
    if high <= low or last <= 0:
        return "WAIT — دادهٔ بازار نامعتبر است."
    position = (last - low) / (high - low)
    if position < 0.25:
        return "WAIT — نزدیک کف روزانه؛ این به‌تنهایی سیگنال خرید نیست."
    if position > 0.85:
        return "WAIT — نزدیک سقف روزانه؛ از تعقیب قیمت پرهیز کن."
    return "WAIT — این نسخه سیگنال قطعی صادر نمی‌کند."
