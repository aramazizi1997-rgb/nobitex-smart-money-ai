from __future__ import annotations
import logging
import os
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from app.market import get_ticker, simple_signal

logging.basicConfig(level=logging.INFO)
load_dotenv()
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "سلام! به ARAM AI QUANT خوش آمدی.\n"
        "دستورها: /status وضعیت ربات، /signal دریافت بررسی نمونه BTCIRT، /help راهنما\n\n"
        "هشدار: این نسخهٔ آزمایشی است؛ سود یا صحت سیگنال تضمین نمی‌شود و معامله‌ای انجام نمی‌دهد."
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "/start — شروع\n/status — وضعیت سرویس\n/signal — بررسی نمونه BTCIRT در نوبیتکس\n\n"
        "این ابزار آموزشی است، توصیهٔ مالی نیست و سفارش خرید/فروش ثبت نمی‌کند."
    )

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("ربات اجراست؛ اتصال داده هنگام اجرای /signal آزمایش می‌شود.")

async def signal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("در حال دریافت دادهٔ عمومی نوبیتکس…")
    try:
        ticker = get_ticker("BTCIRT")
        last = ticker.get("latest", "نامشخص")
        rule = simple_signal(ticker)
        msg = f"BTCIRT | آخرین قیمت: {last}\nنتیجهٔ قاعدهٔ ساده: {rule}\n\nاین تحلیل محدود و آزمایشی است؛ قبل از تصمیم، داده‌ها را مستقل بررسی کن."
    except Exception as exc:
        logging.exception("Market data fetch failed")
        msg = "دریافت داده موفق نشد. ممکن است API یا قالب پاسخ تغییر کرده باشد. بعداً دوباره امتحان کن."
    await update.message.reply_text(msg)

def main() -> None:
    if not TOKEN or TOKEN == "put_your_bot_token_here":
        raise SystemExit("TELEGRAM_BOT_TOKEN را در فایل .env تنظیم کن؛ توکن را عمومی نکن.")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("signal", signal))
    app.run_polling()

if __name__ == "__main__":
    main()
