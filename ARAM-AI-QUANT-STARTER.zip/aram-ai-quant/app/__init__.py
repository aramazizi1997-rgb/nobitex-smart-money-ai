"""ARAM AI QUANT starter package."""
